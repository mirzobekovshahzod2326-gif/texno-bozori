# ТЕХНО БОЗОРИ: Android loyihasi (WebView ilova)

Ilova https://mirzobekovshahzod2326-gif.github.io/texno-bozori/ saytini manzil satrisiz, to'liq ekranda ochadi.
Sayt yangilansa, ilovani qayta yig'ish SHART EMAS (u doim jonli saytni ochadi).

## Android Studio bilan
1. Android Studio (Koala yoki yangiroq) > Open > shu papka. JDK 17, Gradle 8.7+ (Studio o'zi taklif qiladi).
2. Build > Generate Signed Bundle / APK emas, oddiy: terminalda `gradle assembleRelease` yoki
   Build > Build Bundle(s)/APK(s) > Build APK(s) (release).
3. Natija: app/build/outputs/apk/release/app-release.apk (imzolangan, keystore/texno.keystore bilan).

## Imzo kaliti
keystore/texno.keystore va keystore/keystore.properties. Ularni YO'QOTMANG va ommaviy (public) joyga qo'ymang.
Kalit yo'qolsa, ilovani yangilab bo'lmaydi (do'stlar eskisini o'chirib, yangisini o'rnatishi kerak bo'ladi).

## Sayt manzilini o'zgartirish
app/src/main/res/values/strings.xml > start_url.
